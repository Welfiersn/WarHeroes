﻿public enum TypeRole
{
    WARRIOR, ARCHER, MAGE
}
