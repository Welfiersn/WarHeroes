﻿public enum TypeFaction
{
    HUMANS, ORCS, UNDEADS
}

