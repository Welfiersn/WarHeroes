﻿public interface IDataPlayer
{
    public string Name { get; set; }
    public TypeFaction Faction { get; set; }
}